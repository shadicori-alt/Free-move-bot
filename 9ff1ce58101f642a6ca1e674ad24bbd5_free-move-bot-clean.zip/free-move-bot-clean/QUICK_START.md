# 🎯 دليل إنشاء GitHub Repository (3 دقائق)

## ⚡ الطريقة الأسرع: GitHub Web Interface

### **الخطوة 1: إنشاء Repository (30 ثانية)**

**🌐 اذهب لهذا الرابط:**
https://github.com/new

**📝 املأ البيانات:**
- **Repository name**: `free-move-bot`
- **Description**: `بوت Free Move Egypt للـ Facebook Messenger - النسخة المجانية`
- **Public**: ✅ (اختر Public)
- **Initialize with a README file**: ❌ (اختر NO)
- **Add .gitignore**: None
- **Choose a license**: None

**✅ اضغط "Create repository"**

---

### **الخطوة 2: رفع الملفات (2 دقيقة)**

**🎯 في الصفحة الجديدة:**

1. **ابحث عن "uploading an existing file"** (تحت زر Code)
2. **اضغط عليه**
3. **اسحب وأفلت** جميع الملفات من مجلد البوت
4. **أو اضغط "choose your files"** واختر الملفات واحد تلو الآخر

**📁 الملفات المطلوبة:**
- `README.md`
- `package.json`
- `.env.example`
- `.gitignore`
- `setup-and-run.sh`
- `status.html`
- `DEPLOYMENT_GUIDE.md`
- `FILES_CHECKLIST.md`
- مجلد `src/` كامل
- `create-github-repo.sh` (اختياري)

**💡 النصيحة:** ارفع المجلد `src/` كاملاً، ليس ملفات منفصلة

---

### **الخطوة 3: إنشاء Codespace (1 دقيقة)**

**🎯 بعد رفع الملفات:**

1. **اذهب لـ repository** الذي أنشأته
2. **اضغط زر Code** (الأخضر)
3. **اضغط "Create codespace on main"**
4. **انتظر 2-3 دقائق** حتى ينتهي الإعداد

---

### **الخطوة 4: تشغيل البوت (1 دقيقة)**

**🎯 في terminal الـ Codespace:**

```bash
chmod +x setup-and-run.sh
./setup-and-run.sh
```

**أو إذا لم يعمل:**

```bash
npm install
npm start
```

---

### **الخطوة 5: الحصول على URL**

**🎯 بعد تشغيل البوت:**

1. **احصل على URL** من شريط المتصفح أو terminal
2. **مثال**: `https://free-move-bot-abc123.github.dev`
3. **تأكد أن البوت يعمل** بزيارة الرابط

---

## 🔗 الروابط المباشرة

**إنشاء Repository:**
https://github.com/new

**Codespace:**
https://github.com/codespaces/new?repo=free-move-bot

**Repository جاهز (بعد الإنشاء):**
https://github.com/USERNAME/free-move-bot

---

## ✅ تحقق من النجاح

**Repository جاهز إذا:**
- ✅ ظهرت جميع الملفات
- ✅ Codespace يعمل
- ✅ البوت يظهر صفحة جميلة
- ✅ URL يمكن الوصول إليه من المتصفح

**ثم:**
1. **استخدم URL للتحقق من Webhook في Facebook**
2. **Continue مع Facebook Page setup**

---

## 🚨 مشاكل شائعة

### "Repository already exists"
- غير اسم repository لـ `free-move-bot-egypt` أو `freemove-bot`

### "No such file or directory"
- تأكد من رفع جميع الملفات والمجلدات
- تأكد من رفع مجلد `src/` كاملاً

### "Codespace failed to start"
- أعد إنشاء Codespace
- أو استخدم GitHub CLI على الكمبيوتر

---

**💡 باقي الخطوات ستكون في المرجعة التالية!**