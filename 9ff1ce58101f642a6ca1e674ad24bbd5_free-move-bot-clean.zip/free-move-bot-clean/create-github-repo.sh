#!/bin/bash

# GitHub Repository Creation Script
# للتشغيل من terminal على الكمبيوتر أو iPhone مع تطبيق Terminal

echo "🚀 إنشاء repository في GitHub..."
echo "==================================="

# التحقق من وجود Git
if ! command -v git &> /dev/null; then
    echo "❌ Git غير مُثبت"
    echo "📱 قم بتثبيت Git من App Store أو استخدام GitHub web interface"
    exit 1
fi

echo "✅ Git مُثبت"

# الحصول على اسم المستخدم
echo "🔐 احتاج GitHub username"
read -p "أدخل GitHub username: " USERNAME

if [ -z "$USERNAME" ]; then
    echo "❌ username مطلوب"
    exit 1
fi

# إنشاء repository
echo "📁 إنشاء repository..."
REPO_NAME="free-move-bot"

# إضافة remote origin
echo "🔗 إعداد remote repository..."
git remote remove origin 2>/dev/null
git remote add origin https://github.com/$USERNAME/$REPO_NAME.git

# رفع الكود
echo "📤 رفع الكود إلى GitHub..."
git branch -M main

echo "==================================="
echo "🎯 الروابط المفيدة:"
echo "📋 Repository: https://github.com/$USERNAME/$REPO_NAME"
echo "🌐 Codespaces: https://github.com/codespaces/new?repo=$USERNAME/$REPO_NAME"
echo "==================================="

# اختيار طريقة الرفع
echo "اختر طريقة الرفع:"
echo "1) GitHub Web Interface (الأسهل)"
echo "2) Git Push (إذا كان Git مُثبت)"
echo ""
read -p "اختر رقم (1 أو 2): " CHOICE

if [ "$CHOICE" = "1" ]; then
    echo ""
    echo "📱 اذهب للموقع: https://github.com/new"
    echo "📝 املأ البيانات التالية:"
    echo "   Repository name: $REPO_NAME"
    echo "   Description: بوت Free Move Egypt للـ Facebook Messenger - النسخة المجانية"
    echo "   Public: ✅"
    echo "   Initialize with README: ❌"
    echo ""
    echo "🎯 بعد إنشاء الـ repository:"
    echo "1. اذهب للـ repository"
    echo "2. اضغط 'uploading an existing file'"
    echo "3. ارفع جميع الملفات من مجلد البوت"
elif [ "$CHOICE" = "2" ]; then
    git push -u origin main
    echo "✅ تم الرفع بنجاح!"
else
    echo "❌ اختيار غير صحيح"
fi

echo ""
echo "🎉 إنشاء repository مكتمل!"
echo "📋 الخطوة التالية: إنشاء Codespace في GitHub"