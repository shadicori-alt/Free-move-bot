# 🚀 دليل النشر السريع في Codespaces

## الخطوة 1: إنشاء GitHub Repository

### الطريقة الأولى: عبر GitHub.com
1. اذهب لـ [GitHub.com](https://github.com/new)
2. **Repository name**: `free-move-bot`
3. **Description**: `بوت Free Move Egypt للـ Facebook Messenger - النسخة المجانية`
4. **Public**: ✅ اختر هذا الخيار
5. **Initialize**: ❌ لا تقم بإنشاء README (لأنه موجود بالفعل)
6. اضغط **Create repository**

### الطريقة الثانية: تحميل الملفات يدوياً
1. قم بتحميل جميع ملفات `/workspace/free-move-bot-clean/`
2. أنشئ repository جديد في GitHub
3. ارفع الملفات واحد تلو الآخر

## الخطوة 2: إنشاء Codespace

1. اذهب لـ repository الذي أنشأته
2. اضغط زر **Code** (الأخضر)
3. اضغط **Create codespace on main**
4. انتظر حتى يكتمل الإعداد (2-3 دقائق)

## الخطوة 3: تشغيل البوت في Codespace

```bash
# في terminal الـ Codespace:
chmod +x setup-and-run.sh
./setup-and-run.sh
```

أو إذا لم يعمل، قم بتشغيل الأوامر يدوياً:
```bash
npm install
npm start
```

## الخطوة 4: الحصول على URL

بعد التشغيل، احصل على URL الخاص بالـ Codespace:
- ستجده في أعلى الـ terminal
- أو في شريط المتصفح في Codespace
- مثال: `https://free-move-bot-abc123.vercel.app` أو `https://abc123.github.dev`

## الخطوة 5: استخدام URL في Facebook

### إذا كان البوت يعمل بنجاح:
1. افتح Facebook Developers Dashboard
2. اذهب لـ Messenger Platform
3. في **Webhook** section:
   - **Callback URL**: `https://your-codespace-url/api/messenger/webhook`
   - **Verify Token**: `FreeMoveBot2025`
4. اضغط **Verify & Save**

### إذا ظهر خطأ في التحقق:
- تأكد أن الـ Codespace يعمل والـ URL صحيح
- تأكد من أن Verify Token مطابق تماماً: `FreeMoveBot2025`

## ✅ نماذج عمل

**Webhook URL صحيح:**
- يجب أن يبدأ بـ `https://`
- ينتهي بـ `/api/messenger/webhook`
- يمكن الوصول إليه من المتصفح بدون login

**البوت يعمل بنجاح:**
- ستظهر صفحة جميلة مع معلومات البوت
- ستظهر رسالة "البوت يعمل بنجاح" باللون الأخضر

## 🎯 الخطوات التالية بعد التحقق الناجح

1. **إنشاء Facebook Page** لـ "Free Move Egypt"
2. **ربط الصفحة** مع Bot
3. **الحصول على Page Access Token**
4. **ملء .env** بالـ Token
5. **إعادة تشغيل البوت**

## 📞 المشاكل الشائعة

### "Verify Failed"
- ✅ تأكد أن Codespace يعمل
- ✅ تأكد أن URL صحيح
- ✅ تأكد أن Verify Token مطابق

### "Port 3000 already in use"
```bash
# قتل العمليات على المنفذ 3000
lsof -ti:3000 | xargs kill -9
npm start
```

### لم تظهر صفحة الويب
- تأكد أن `npm install` تم بنجاح
- تأكد أن `npm start` يعمل بدون أخطاء
- انتظر 30 ثانية للـ Codespace

## 🚨 ملاحظات مهمة

- Codespace مجاني لمدة 60 ساعة شهرياً
- البوت سيتوقف عند إغلاق Codespace (للاستخدام المستمر، تحتاج hosting permanent)
- هذا مُحسَّن فقط للمرحلة الأولى (التحقق من Facebook)
- لاحقاً سننتقل لحل مستدام

---

**💡 النصيحة**: احتفظ بهذا الدليل للاستخدام المستقبلي!