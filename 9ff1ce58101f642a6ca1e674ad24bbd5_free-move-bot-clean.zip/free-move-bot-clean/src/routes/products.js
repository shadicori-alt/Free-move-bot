const express = require('express');
const router = express.Router();
const { PRODUCTS } = require('../config/products');
const { db } = require('../config/database');

// جلب جميع المنتجات
router.get('/', (req, res) => {
  try {
    const products = db.prepare('SELECT * FROM products').all();

    // إذا كانت قاعدة البيانات فارغة، أرجع المنتجات الثابتة
    if (products.length === 0) {
      return res.json({
        success: true,
        count: Object.keys(PRODUCTS).length,
        data: Object.values(PRODUCTS)
      });
    }

    res.json({
      success: true,
      count: products.length,
      data: products
    });
  } catch (error) {
    console.error('خطأ في جلب المنتجات:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// جلب منتج واحد
router.get('/:id', (req, res) => {
  try {
    const { id } = req.params;

    const product = db.prepare('SELECT * FROM products WHERE id = ?').get(id);

    if (!product) {
      // البحث في المنتجات الثابتة
      const staticProduct = Object.values(PRODUCTS).find(p => p.id === id);
      if (staticProduct) {
        return res.json({
          success: true,
          data: staticProduct
        });
      }
      return res.status(404).json({ success: false, error: 'المنتج غير موجود' });
    }

    res.json({
      success: true,
      data: product
    });
  } catch (error) {
    console.error('خطأ في جلب المنتج:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
