const express = require('express');
const router = express.Router();
const { db } = require('../config/database');

// جلب جميع العملاء
router.get('/', (req, res) => {
  try {
    const { limit = 100, offset = 0 } = req.query;

    const customers = db.prepare(`
      SELECT *
      FROM customers
      ORDER BY created_at DESC
      LIMIT ? OFFSET ?
    `).all(parseInt(limit), parseInt(offset));

    res.json({
      success: true,
      count: customers.length,
      data: customers
    });
  } catch (error) {
    console.error('خطأ في جلب العملاء:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// جلب عميل واحد
router.get('/:id', (req, res) => {
  try {
    const { id } = req.params;

    const customer = db.prepare('SELECT * FROM customers WHERE id = ?').get(id);

    if (!customer) {
      return res.status(404).json({ success: false, error: 'العميل غير موجود' });
    }

    // جلب طلبات العميل
    const orders = db.prepare(`
      SELECT * FROM orders WHERE customer_id = ? ORDER BY created_at DESC
    `).all(id);

    // جلب محادثات العميل
    const conversations = db.prepare(`
      SELECT * FROM conversations WHERE customer_id = ? ORDER BY timestamp DESC LIMIT 50
    `).all(id);

    res.json({
      success: true,
      data: {
        ...customer,
        orders,
        conversations
      }
    });
  } catch (error) {
    console.error('خطأ في جلب العميل:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// تحديث بيانات عميل
router.patch('/:id', (req, res) => {
  try {
    const { id } = req.params;
    const { name, phone, email, address, city, pain_type, notes } = req.body;

    const updates = [];
    const values = [];

    if (name) { updates.push('name = ?'); values.push(name); }
    if (phone) { updates.push('phone = ?'); values.push(phone); }
    if (email) { updates.push('email = ?'); values.push(email); }
    if (address) { updates.push('address = ?'); values.push(address); }
    if (city) { updates.push('city = ?'); values.push(city); }
    if (pain_type) { updates.push('pain_type = ?'); values.push(pain_type); }
    if (notes) { updates.push('notes = ?'); values.push(notes); }

    if (updates.length === 0) {
      return res.status(400).json({ success: false, error: 'لا توجد بيانات للتحديث' });
    }

    updates.push('updated_at = CURRENT_TIMESTAMP');
    values.push(id);

    const result = db.prepare(`
      UPDATE customers
      SET ${updates.join(', ')}
      WHERE id = ?
    `).run(...values);

    if (result.changes === 0) {
      return res.status(404).json({ success: false, error: 'العميل غير موجود' });
    }

    res.json({
      success: true,
      message: 'تم تحديث بيانات العميل بنجاح'
    });
  } catch (error) {
    console.error('خطأ في تحديث العميل:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
