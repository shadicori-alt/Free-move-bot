const express = require('express');
const router = express.Router();
const ordersController = require('../controllers/ordersController');

// جلب جميع الطلبات
router.get('/', (req, res) => ordersController.getAllOrders(req, res));

// جلب إحصائيات الطلبات
router.get('/stats', (req, res) => ordersController.getOrderStats(req, res));

// جلب طلب واحد
router.get('/:id', (req, res) => ordersController.getOrder(req, res));

// إنشاء طلب جديد
router.post('/', (req, res) => ordersController.createOrder(req, res));

// تحديث حالة الطلب
router.patch('/:id/status', (req, res) => ordersController.updateOrderStatus(req, res));

module.exports = router;
