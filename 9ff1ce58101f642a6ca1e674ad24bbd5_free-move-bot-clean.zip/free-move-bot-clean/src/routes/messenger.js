const express = require('express');
const router = express.Router();
const messengerController = require('../controllers/messengerController');

// التحقق من webhook
router.get('/webhook', (req, res) => messengerController.verifyWebhook(req, res));

// استقبال الأحداث
router.post('/webhook', (req, res) => messengerController.handleWebhook(req, res));

module.exports = router;
