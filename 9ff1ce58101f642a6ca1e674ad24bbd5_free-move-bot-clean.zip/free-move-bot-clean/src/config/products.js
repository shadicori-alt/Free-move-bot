/**
 * معلومات منتجات Free Move
 * (يمكن تحديثها تلقائياً من Shopify)
 */

const PRODUCTS = {
  large: {
    id: 'large-patch',
    name: 'لاصقات Free Move الكبيرة',
    originalPrice: 350,
    salePrice: 299,
    discount: 15,
    description: 'لاصقات علاجية كبيرة للظهر والعمود الفقري بتقنية كندية معتمدة',
    benefits: [
      'تقنية كندية معتمدة مع براءة اختراع',
      'علاج طبيعي بدون أدوية أو مواد كيميائية',
      'نتائج مضمونة خلال أسبوع',
      'مقاومة للماء ويمكن استخدامها أثناء الرياضة',
      'أمان كامل بدون آثار جانبية'
    ],
    painPoints: ['ألم الظهر', 'العمود الفقري', 'آلام العضلات الكبيرة', 'الإصابات الرياضية'],
    category: 'large'
  },
  
  medium: {
    id: 'medium-patch',
    name: 'لاصقات Free Move المتوسطة',
    originalPrice: 280,
    salePrice: 239,
    discount: 15,
    description: 'لاصقات علاجية متوسطة للركبة والكتف والمفاصل',
    benefits: [
      'تقنية كندية معتمدة مع براءة اختراع',
      'مرونة عالية تتكيف مع حركة المفاصل',
      'سهلة الاستخدام والإزالة',
      'تخفيف فوري للألم',
      'مناسبة للاستخدام اليومي'
    ],
    painPoints: ['ألم الركبة', 'ألم الكتف', 'المفاصل الصغيرة', 'التهاب المفاصل'],
    category: 'medium'
  },
  
  small: {
    id: 'small-patch',
    name: 'لاصقات Free Move الصغيرة',
    originalPrice: 290,
    salePrice: 247,
    discount: 15,
    description: 'لاصقات علاجية صغيرة للرأس والرقبة والمناطق الحساسة',
    benefits: [
      'تقنية كندية معتمدة مع براءة اختراع',
      'أمان كامل للمناطق الحساسة',
      'تخفيف سريع للصداع وآلام الرقبة',
      'يمكن استخدامها تحت الملابس',
      'مناسبة للاستخدام اليومي'
    ],
    painPoints: ['ألم الرأس', 'الصداع', 'ألم الرقبة', 'الصداع النصفي', 'توتر العضلات'],
    category: 'small'
  }
};

const DELIVERY_OPTIONS = {
  standard: {
    name: 'توصيل عادي',
    duration: '24-48 ساعة',
    cost: 30,
    coverage: 'جميع المحافظات'
  },
  fast: {
    name: 'توصيل سريع',
    duration: '4-12 ساعة',
    cost: 50,
    coverage: 'القاهرة الكبرى فقط'
  },
  pickup: {
    name: 'استلام من الفرع',
    duration: '2-3 ساعات',
    cost: 0,
    coverage: 'نقاط الاستلام المحددة'
  }
};

const PAYMENT_METHODS = {
  cash: {
    name: 'الدفع عند الاستلام',
    commission: 15
  },
  online: {
    name: 'دفع إلكتروني',
    commission: 0,
    methods: ['فيزا', 'ماستركارد', 'فودافون كاش']
  }
};

const SPECIAL_OFFERS = {
  firstOrder: {
    name: 'خصم الطلب الأول',
    discount: 20,
    description: 'خصم 20٪ على طلبك الأول'
  },
  freeShipping: {
    name: 'شحن مجاني',
    minOrder: 300,
    description: 'شحن مجاني للطلبات فوق 300 جنيه'
  },
  moneyBack: {
    name: 'ضمان استرداد الأموال',
    days: 30,
    description: 'ضمان استرداد كامل خلال 30 يوم'
  }
};

module.exports = {
  PRODUCTS,
  DELIVERY_OPTIONS,
  PAYMENT_METHODS,
  SPECIAL_OFFERS
};
