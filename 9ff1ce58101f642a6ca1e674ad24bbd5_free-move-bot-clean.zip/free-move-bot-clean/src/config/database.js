const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');

// إنشاء مجلد قاعدة البيانات إذا لم يكن موجوداً
const dbPath = path.join(__dirname, '../../../database/freemove.db');
const dbDir = path.dirname(dbPath);

if (!fs.existsSync(dbDir)) {
  fs.mkdirSync(dbDir, { recursive: true });
}

// الاتصال بقاعدة البيانات
const db = new Database(dbPath, { verbose: console.log });

// تفعيل Foreign Keys
db.pragma('foreign_keys = ON');

/**
 * إنشاء جداول قاعدة البيانات
 */
function initDatabase() {
  // جدول العملاء
  db.exec(`
    CREATE TABLE IF NOT EXISTS customers (
      id TEXT PRIMARY KEY,
      facebook_id TEXT UNIQUE NOT NULL,
      name TEXT NOT NULL,
      phone TEXT,
      email TEXT,
      address TEXT,
      city TEXT,
      pain_type TEXT,
      interest_level TEXT DEFAULT 'متوسط',
      preferred_product TEXT,
      interaction_count INTEGER DEFAULT 0,
      conversion_status TEXT DEFAULT 'محتمل',
      notes TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // جدول المنتجات
  db.exec(`
    CREATE TABLE IF NOT EXISTS products (
      id TEXT PRIMARY KEY,
      shopify_id TEXT UNIQUE,
      name TEXT NOT NULL,
      description TEXT,
      price REAL NOT NULL,
      original_price REAL,
      image_url TEXT,
      category TEXT,
      pain_points TEXT,
      benefits TEXT,
      in_stock BOOLEAN DEFAULT 1,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // جدول الطلبات
  db.exec(`
    CREATE TABLE IF NOT EXISTS orders (
      id TEXT PRIMARY KEY,
      customer_id TEXT NOT NULL,
      status TEXT DEFAULT 'قيد الانتظار',
      total_price REAL NOT NULL,
      delivery_type TEXT,
      delivery_cost REAL DEFAULT 0,
      payment_method TEXT,
      tracking_number TEXT,
      notes TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE
    )
  `);

  // جدول تفاصيل الطلبات
  db.exec(`
    CREATE TABLE IF NOT EXISTS order_items (
      id TEXT PRIMARY KEY,
      order_id TEXT NOT NULL,
      product_id TEXT NOT NULL,
      quantity INTEGER NOT NULL DEFAULT 1,
      price REAL NOT NULL,
      subtotal REAL NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
      FOREIGN KEY (product_id) REFERENCES products(id)
    )
  `);

  // جدول سجل المحادثات
  db.exec(`
    CREATE TABLE IF NOT EXISTS conversations (
      id TEXT PRIMARY KEY,
      customer_id TEXT NOT NULL,
      message_type TEXT NOT NULL,
      message_content TEXT NOT NULL,
      bot_response TEXT,
      intent TEXT,
      timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE
    )
  `);

  // جدول تاريخ حالات الطلبات
  db.exec(`
    CREATE TABLE IF NOT EXISTS order_status_history (
      id TEXT PRIMARY KEY,
      order_id TEXT NOT NULL,
      status TEXT NOT NULL,
      changed_by TEXT,
      notes TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
    )
  `);

  // إنشاء الفهارس لتحسين الأداء
  db.exec(`
    CREATE INDEX IF NOT EXISTS idx_customers_facebook_id ON customers(facebook_id);
    CREATE INDEX IF NOT EXISTS idx_orders_customer_id ON orders(customer_id);
    CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
    CREATE INDEX IF NOT EXISTS idx_order_items_order_id ON order_items(order_id);
    CREATE INDEX IF NOT EXISTS idx_conversations_customer_id ON conversations(customer_id);
  `);

  console.log('✓ تم إنشاء قاعدة البيانات بنجاح');
}

module.exports = {
  db,
  initDatabase
};
