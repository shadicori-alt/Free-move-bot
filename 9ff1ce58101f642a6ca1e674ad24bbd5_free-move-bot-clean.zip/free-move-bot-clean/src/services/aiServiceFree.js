const { PRODUCTS } = require('../config/products');

/**
 * نظام الذكاء الاصطناعي المجاني للمحادثة
 * يعمل بدون OpenAI API - مجاني 100%
 */
class AIServiceFree {
  constructor() {
    this.conversationHistory = new Map();
    this.conversations = new Map();
    
    // قواعد البيانات للردود الذكية
    this.responses = {
      greeting: [
        "مرحباً بك في Free Move Egypt! أنا مساعدك الذكي للتعرف على منتجاتنا الطبية المبتكرة. نحن نقدم لاصقات علاجية كندية معتمدة بتقنية فريدة لعلاج الآلام بشكل طبيعي وآمن. دعني أساعدك في العثور على المنتج المناسب لك. ما نوع الألم أو المشكلة التي تواجهها؟",
        "السلام عليكم ورحمة الله وبركاته! أهلاً وسهلاً بك في Free Move. نحن متخصصون في علاج الآلام العضلية والمفاصل باستخدام تقنيات متقدمة. كيف يمكنني مساعدتك اليوم؟",
        "أهلاً وسهلاً! مرحباً بك في Free Move Egypt. نحن نقدم أفضل الحلول الطبية لآلام العضلات والمفاصل. ما المشكلة التي تواجهها حتى أتمكن من مساعدتك؟"
      ],
      
      pain_responses: {
        'ظهر': {
          message: "آلام الظهر من أكثر المشاكل شيوعاً! لدينا لاصق الظهر الكامل (كبير) مصمم خصيصاً لعلاج آلام الظهر والعمود الفقري. يحتوي على مواد طبيعية مسكنة ومضادة للالتهاب.",
          product: PRODUCTS.large
        },
        'رقبة': {
          message: "آلام الرقبة والصداع تحتاج حل سريع! لاصق الرقبة الصغير مثالي للتخلص من آلام الرقبة والصداع خلال دقائق.",
          product: PRODUCTS.small
        },
        'ركبة': {
          message: "آلام الركبة تعيق الحركة! لاصق الركبة (متوسط) علاج مثالي لتخفيف آلام الركبة والمفاصل، يفضله الرياضيون جداً.",
          product: PRODUCTS.medium
        },
        'كتف': {
          message: "آلام الكتف شائعة جداً! لاصق الكتف (متوسط) يساعد في علاج آلام الكتف والذراع بطريقة فعالة.",
          product: PRODUCTS.medium
        },
        'مفاصل': {
          message: "آلام المفاصل تحتاج عناية خاصة! منتجاتنا مناسبة لجميع أنواع آلام المفاصل. دعني أعرف أكثر عن موقع الألم.",
          product: null
        },
        'عضلات': {
          message: "آلام العضلات بعد التمارين شائعة! منتجاتنا مناسبة لتخفيف آلام العضلات سواء كان ذلك بعد الرياضة أو العمل الشاق.",
          product: null
        }
      },
      
      inquiry_responses: [
        "منتجاتنا مصنوعة في كندا ومعتمدة من منظمة الغذاء والدواء الأمريكية FDA. تحتوي على مكونات طبيعية مسكنة ومضادة للالتهاب. فعالية مثبتة سريرياً!",
        "مميزات منتجاتنا:\n• تقنية كندية مبتكرة\n• مواد طبيعية آمنة\n• فعالية سريعة (خلال 15-30 دقيقة)\n• ضمان 30 يوم\n• تقييم عملاء 4.8/5",
        "جميع منتجاتنا:\n• خالية من الكورتيزون والمواد الضارة\n• تعمل لمدة 12 ساعة متواصلة\n• مناسبة لجميع الأعمار\n• متوفرة بسعر خاص بخصم يصل 30%"
      ],
      
      price_responses: [
        "أسعارنا منافسة جداً مقارنة بالعلاجات الأخرى:\n• لاصق صغير: 145 جنيه (كان 199)\n• لاصق متوسط: 185 جنيه (كان 259) \n• لاصق كبير: 245 جنيه (كان 349)\n• خصم حتى 30% لفترة محدودة!",
        "أسعارنا شاملة:\n• نفس السعر أياً كان مكان تواجدك\n• توصيل مجاني للاستلام من الفرع\n• دفع عند الاستلام متاح\n• ضمان استرداد كامل خلال 30 يوم"
      ],
      
      order_responses: [
        "ممتاز! سأساعدك في إتمام الطلب. أحتاج منك المعلومات التالية:\n1. الاسم الكامل\n2. رقم الهاتف\n3. المحافظة\n4. المدينة\n5. العنوان بالتفصيل",
        "رائع! لبدء الطلب، من فضلك قدم لي:\n• اسمك\n• رقم الهاتف للتواصل\n• المحافظة والمدينة\n• العنوان\nوبالتالي سأحسب تكلفة التوصيل وأؤكد معك التفاصيل."
      ],
      
      delivery_responses: [
        "نقدم 3 خيارات للتوصيل:\n• عادي (30 جنيه) - خلال 2-3 أيام\n• سريع (50 جنيه) - خلال 24-48 ساعة\n• استلام مجاني - من فرعنا في القاهرة الكبرى",
        "التوصيل متاح لجميع محافظات مصر:\n• القاهرة الكبرى: توصيل يومي\n• باقي المحافظات: خلال 2-5 أيام\n• خدمة عملاء متاحة 24/7"
      ],
      
      default_response: "شكراً لك على تواصلك معنا. أنا هنا لمساعدتك في اختيار أفضل منتج Free Move يناسب احتياجاتك. يمكنني مساعدتك في:\n• معرفة المنتجات المناسبة لك\n• عرض الأسعار والعروض\n• إتمام الطلب\n• معلومات التوصيل والدفع\nما الذي تريد معرفته؟"
    };
    
    this.keywords = {
      greeting: ['مرحبا', 'سلام', 'هلا', 'السلام', 'أهلا', 'مرحب'],
      pain: ['ألم', 'وجع', 'يؤلمني', 'تعبان', 'مشكلة', 'ساعدي', 'ريد', 'بحث'],
      inquiry: ['معلومات', 'ما هو', 'كيف', 'هل', 'استفسار', 'مميزات', 'فوائد', 'طبيعي'],
      price: ['سعر', 'كام', 'تكلفة', 'فلوس', 'ثمن', 'أسعار', 'خصم'],
      order: ['اطلب', 'أريد', 'عايز', 'شراء', 'احجز', 'طلب', 'شراء'],
      delivery: ['توصيل', 'شحن', 'استلام', 'متى', 'يصل', 'وصول'],
      pain_keywords: ['ظهر', 'عمود فقري', 'رأس', 'صداع', 'رقبة', 'ركبة', 'كتف', 'مفاصل', 'عضلات', 'عنق']
    };
  }

  /**
   * تحليل نية العميل من الرسالة
   */
  analyzeIntent(message) {
    const lowerMessage = message.toLowerCase();
    
    // فحص كلمات المفتاح للترحيب
    if (this.keywords.greeting.some(word => lowerMessage.includes(word))) {
      return 'greeting';
    }
    
    // فحص كلمات المفتاح لآلام
    if (this.keywords.pain.some(word => lowerMessage.includes(word))) {
      return 'pain';
    }
    
    // فحص كلمات مفتاح الآلام المحددة
    if (this.keywords.pain_keywords.some(word => lowerMessage.includes(word))) {
      return 'pain_specific';
    }
    
    // فحص كلمات مفتاح الاستفسار
    if (this.keywords.inquiry.some(word => lowerMessage.includes(word))) {
      return 'inquiry';
    }
    
    // فحص كلمات مفتاح الأسعار
    if (this.keywords.price.some(word => lowerMessage.includes(word))) {
      return 'price';
    }
    
    // فحص كلمات مفتاح الطلبات
    if (this.keywords.order.some(word => lowerMessage.includes(word))) {
      return 'order';
    }
    
    // فحص كلمات مفتاح التوصيل
    if (this.keywords.delivery.some(word => lowerMessage.includes(word))) {
      return 'delivery';
    }
    
    return 'general';
  }

  /**
   * اختيار المنتج المناسب بناءً على نوع الألم
   */
  getProductForPain(painType) {
    for (const [key, product_info] of Object.entries(this.responses.pain_responses)) {
      if (painType.toLowerCase().includes(key)) {
        return product_info;
      }
    }
    return { message: "دعني أعرف أكثر عن موقع الألم لأرشدك للمنتج المناسب.", product: null };
  }

  /**
   * الحصول على رد عشوائي من مجموعة الردود
   */
  getRandomResponse(responses) {
    const randomIndex = Math.floor(Math.random() * responses.length);
    return responses[randomIndex];
  }

  /**
   * توليد رد ذكي بدون OpenAI
   */
  async generateResponse(userId, message, customerData = {}) {
    try {
      // تحليل النية
      const intent = this.analyzeIntent(message);
      
      // جلب سجل المحادثة
      let conversation = this.conversations.get(userId) || {
        messages: [],
        step: 'welcome',
        data: {}
      };

      // إضافة رسالة العميل
      conversation.messages.push({
        role: 'user',
        content: message,
        intent: intent,
        timestamp: new Date()
      });

      let response = '';
      let suggestedProduct = null;
      let nextStep = conversation.step;

      switch (intent) {
        case 'greeting':
          response = this.getRandomResponse(this.responses.greeting);
          nextStep = 'pain_inquiry';
          break;

        case 'pain':
        case 'pain_specific':
          const painInfo = this.getProductForPain(message);
          response = painInfo.message;
          suggestedProduct = painInfo.product;
          nextStep = 'product_info';
          break;

        case 'inquiry':
          response = this.getRandomResponse(this.responses.inquiry_responses);
          nextStep = 'continue';
          break;

        case 'price':
          response = this.getRandomResponse(this.responses.price_responses);
          nextStep = 'order_prompt';
          break;

        case 'order':
          response = this.getRandomResponse(this.responses.order_responses);
          nextStep = 'collect_order_info';
          break;

        case 'delivery':
          response = this.getRandomResponse(this.responses.delivery_responses);
          nextStep = 'order_prompt';
          break;

        default:
          response = this.responses.default_response;
          nextStep = 'continue';
      }

      // إضافة رد البوت للسجل
      conversation.messages.push({
        role: 'assistant',
        content: response,
        timestamp: new Date()
      });

      // تحديث سجل المحادثة
      conversation.step = nextStep;
      this.conversations.set(userId, conversation);

      return {
        response,
        intent,
        suggestedProduct,
        step: nextStep
      };

    } catch (error) {
      console.error('خطأ في توليد الرد:', error);
      return {
        response: "عذراً، حدث خطأ مؤقت. من فضلك حاول مرة أخرى أو اتصل بخدمة العملاء.",
        intent: 'error',
        suggestedProduct: null,
        step: 'error'
      };
    }
  }

  /**
   * جمع بيانات الطلب
   */
  collectOrderData(userId, message, conversation) {
    const step = conversation.step;
    let response = '';
    let completed = false;

    switch (step) {
      case 'collect_name':
        conversation.data.name = message;
        response = "رائع! الآن أحتاج رقم هاتفك للتواصل معك.";
        conversation.step = 'collect_phone';
        break;

      case 'collect_phone':
        if (this.isValidPhone(message)) {
          conversation.data.phone = message;
          response = "ممتاز! الآن أحتاج منك المحافظة التي تريد التوصيل إليها.";
          conversation.step = 'collect_governorate';
        } else {
          response = "من فضلك أدخل رقم هاتف صحيح (مثال: 01234567890)";
          conversation.step = 'collect_phone';
        }
        break;

      case 'collect_governorate':
        conversation.data.governorate = message;
        response = "الآن أحتاج المدينة.";
        conversation.step = 'collect_city';
        break;

      case 'collect_city':
        conversation.data.city = message;
        response = "أخيراً، أحتاج العنوان بالتفصيل (الحي - الشارع - رقم البناء).";
        conversation.step = 'collect_address';
        break;

      case 'collect_address':
        conversation.data.address = message;
        response = this.generateOrderSummary(conversation.data);
        conversation.step = 'order_confirmed';
        completed = true;
        break;

      default:
        response = "من فضلك قم بإرسال المعلومات المطلوبة بالترتيب: الاسم، رقم الهاتف، المحافظة، المدينة، العنوان.";
    }

    this.conversations.set(userId, conversation);
    
    return {
      response,
      data: conversation.data,
      completed,
      step: conversation.step
    };
  }

  /**
   * التحقق من صحة رقم الهاتف
   */
  isValidPhone(phone) {
    const phoneRegex = /^[01][0-9]{10}$/;
    return phoneRegex.test(phone.replace(/\s/g, ''));
  }

  /**
   * توليد ملخص الطلب
   */
  generateOrderSummary(data) {
    return `ممتاز! تم تأكيد طلبك بنجاح.

📋 **تفاصيل الطلب:**
الاسم: ${data.name}
الهاتف: ${data.phone}
المحافظة: ${data.governorate}
المدينة: ${data.city}
العنوان: ${data.address}

🎯 **المطلوب الآن:**
1. تأكيد المنتج المطلوب (سأرسل لك المنتجات المتاحة)
2. طريقة التوصيل المفضلة (عادي 30ج / سريع 50ج / استلام مجاني)
3. طريقة الدفع (عند الاستلام / إلكتروني)

سيتم التواصل معك خلال 15 دقيقة لتأكيد الطلب.

شكراً لثقتك في Free Move Egypt! 🏥`;
  }

  /**
   * مسح سجل المحادثة
   */
  clearHistory(userId) {
    this.conversations.delete(userId);
  }

  /**
   * الحصول على رسالة ترحيبية
   */
  getWelcomeMessage() {
    return this.getRandomResponse(this.responses.greeting);
  }

  /**
   * الحصول على رسالة طلب
   */
  getOrderMessage() {
    return this.getRandomResponse(this.responses.order_responses);
  }
}

module.exports = new AIServiceFree();