const axios = require('axios');

/**
 * خدمة التكامل مع Shopify
 */
class ShopifyService {
  constructor() {
    this.storeUrl = process.env.SHOPIFY_STORE_URL;
    this.accessToken = process.env.SHOPIFY_ACCESS_TOKEN;
    this.apiVersion = '2024-01';
    this.baseUrl = `${this.storeUrl}/admin/api/${this.apiVersion}`;
  }

  /**
   * جلب جميع المنتجات
   */
  async getProducts(limit = 50) {
    try {
      const response = await axios.get(
        `${this.baseUrl}/products.json`,
        {
          params: { limit },
          headers: {
            'X-Shopify-Access-Token': this.accessToken
          }
        }
      );

      return response.data.products || [];
    } catch (error) {
      console.error('خطأ في جلب المنتجات:', error.response?.data || error.message);
      return [];
    }
  }

  /**
   * جلب منتج واحد
   */
  async getProduct(productId) {
    try {
      const response = await axios.get(
        `${this.baseUrl}/products/${productId}.json`,
        {
          headers: {
            'X-Shopify-Access-Token': this.accessToken
          }
        }
      );

      return response.data.product;
    } catch (error) {
      console.error('خطأ في جلب المنتج:', error.response?.data || error.message);
      return null;
    }
  }

  /**
   * جلب معلومات المخزون
   */
  async getInventory(variantId) {
    try {
      const response = await axios.get(
        `${this.baseUrl}/inventory_levels.json`,
        {
          params: { inventory_item_ids: variantId },
          headers: {
            'X-Shopify-Access-Token': this.accessToken
          }
        }
      );

      return response.data.inventory_levels || [];
    } catch (error) {
      console.error('خطأ في جلب المخزون:', error.response?.data || error.message);
      return [];
    }
  }

  /**
   * إنشاء طلب في Shopify
   */
  async createOrder(orderData) {
    try {
      const response = await axios.post(
        `${this.baseUrl}/orders.json`,
        { order: orderData },
        {
          headers: {
            'X-Shopify-Access-Token': this.accessToken,
            'Content-Type': 'application/json'
          }
        }
      );

      return response.data.order;
    } catch (error) {
      console.error('خطأ في إنشاء الطلب:', error.response?.data || error.message);
      throw error;
    }
  }

  /**
   * تحديث حالة الطلب
   */
  async updateOrder(orderId, updateData) {
    try {
      const response = await axios.put(
        `${this.baseUrl}/orders/${orderId}.json`,
        { order: updateData },
        {
          headers: {
            'X-Shopify-Access-Token': this.accessToken,
            'Content-Type': 'application/json'
          }
        }
      );

      return response.data.order;
    } catch (error) {
      console.error('خطأ في تحديث الطلب:', error.response?.data || error.message);
      throw error;
    }
  }

  /**
   * تحويل بيانات المنتج لصيغة قاعدة البيانات
   */
  formatProduct(shopifyProduct) {
    const variant = shopifyProduct.variants?.[0] || {};
    
    return {
      id: `shopify_${shopifyProduct.id}`,
      shopify_id: shopifyProduct.id.toString(),
      name: shopifyProduct.title,
      description: shopifyProduct.body_html?.replace(/<[^>]*>/g, '') || '',
      price: parseFloat(variant.price) || 0,
      original_price: parseFloat(variant.compare_at_price) || parseFloat(variant.price) || 0,
      image_url: shopifyProduct.images?.[0]?.src || null,
      category: shopifyProduct.product_type || 'general',
      in_stock: variant.inventory_quantity > 0
    };
  }
}

module.exports = new ShopifyService();
