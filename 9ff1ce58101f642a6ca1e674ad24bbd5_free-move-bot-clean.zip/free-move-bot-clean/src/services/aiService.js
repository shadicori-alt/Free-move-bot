const OpenAI = require('openai');
const { PRODUCTS } = require('../config/products');

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

/**
 * نظام الذكاء الاصطناعي للمحادثة
 */
class AIService {
  constructor() {
    this.conversationHistory = new Map();
    this.systemPrompt = this.createSystemPrompt();
  }

  createSystemPrompt() {
    const productList = Object.values(PRODUCTS)
      .map(p => `- ${p.name}: ${p.salePrice} جنيه (كان ${p.originalPrice} جنيه) - ${p.description}`)
      .join('\n');

    return `أنت مساعد مبيعات ذكي لمنتجات Free Move الطبية المتخصصة في لاصقات الشد والشفاء.

معلومات المنتجات:
${productList}

دورك:
1. الترحيب بالعملاء بطريقة ودية ومهنية
2. فهم نوع الألم أو المشكلة التي يواجهونها
3. اقتراح المنتج المناسب بناءً على احتياجاتهم
4. شرح مميزات المنتج بطريقة إقناعية
5. الإجابة على الأسئلة والشكوك
6. توجيههم لإتمام الطلب
7. التعامل مع الاعتراضات بذكاء

أسلوب الردود:
- استخدم اللغة العربية الفصحى البسيطة
- كن دافئاً ومحترماً
- استخدم الإقناع بالفوائد والنتائج
- أظهر التعاطف مع مشكلة العميل
- قدم ضمانات وإحصائيات موثوقة
- لا تستخدم الرموز التعبيرية (emoji)

معلومات إضافية:
- تقنية كندية معتمدة مع براءة اختراع
- أكثر من 10,000 عميل راضٍ
- ضمان استرداد كامل خلال 30 يوم
- تقييم 4.8 من 5 من العملاء
- توصيل لجميع أنحاء مصر`;
  }

  /**
   * تحليل نية العميل من الرسالة
   */
  async analyzeIntent(message) {
    const intents = {
      greeting: ['مرحبا', 'سلام', 'هلا', 'السلام عليكم'],
      inquiry: ['معلومات', 'ما هو', 'كيف', 'هل', 'استفسار'],
      pain: ['ألم', 'وجع', 'يؤلمني', 'تعبان', 'مشكلة'],
      price: ['سعر', 'كام', 'تكلفة', 'فلوس', 'ثمن'],
      order: ['اطلب', 'أريد', 'عايز', 'شراء', 'احجز'],
      delivery: ['توصيل', 'شحن', 'استلام', 'متى يصل'],
      payment: ['دفع', 'فلوس', 'الدفع عند الاستلام']
    };

    const lowerMessage = message.toLowerCase();
    
    for (const [intent, keywords] of Object.entries(intents)) {
      if (keywords.some(keyword => lowerMessage.includes(keyword))) {
        return intent;
      }
    }

    return 'general';
  }

  /**
   * اقتراح المنتج المناسب بناءً على نوع الألم
   */
  suggestProduct(painType) {
    const painTypeLower = painType.toLowerCase();
    
    if (painTypeLower.includes('ظهر') || painTypeLower.includes('عمود فقري')) {
      return PRODUCTS.large;
    } else if (painTypeLower.includes('ركبة') || painTypeLower.includes('كتف')) {
      return PRODUCTS.medium;
    } else if (painTypeLower.includes('رأس') || painTypeLower.includes('رقبة') || painTypeLower.includes('صداع')) {
      return PRODUCTS.small;
    }
    
    return null;
  }

  /**
   * توليد رد ذكي باستخدام OpenAI
   */
  async generateResponse(userId, message, customerData = {}) {
    try {
      // تحليل النية
      const intent = await this.analyzeIntent(message);

      // جلب سجل المحادثة
      let history = this.conversationHistory.get(userId) || [];

      // إضافة رسالة العميل
      history.push({
        role: 'user',
        content: message
      });

      // بناء السياق
      const contextMessages = [
        { role: 'system', content: this.systemPrompt },
        ...history.slice(-10) // آخر 10 رسائل فقط
      ];

      // إضافة معلومات العميل إن وجدت
      if (customerData.name) {
        contextMessages.push({
          role: 'system',
          content: `معلومات العميل: الاسم: ${customerData.name}${customerData.pain_type ? `, نوع الألم: ${customerData.pain_type}` : ''}`
        });
      }

      // استدعاء OpenAI
      const completion = await openai.chat.completions.create({
        model: 'gpt-4',
        messages: contextMessages,
        temperature: 0.8,
        max_tokens: 500
      });

      const response = completion.choices[0].message.content;

      // إضافة رد البوت للسجل
      history.push({
        role: 'assistant',
        content: response
      });

      // حفظ السجل (احتفظ بآخر 20 رسالة فقط)
      this.conversationHistory.set(userId, history.slice(-20));

      return {
        response,
        intent,
        suggestedProduct: this.suggestProduct(message)
      };
    } catch (error) {
      console.error('خطأ في توليد الرد:', error);
      return {
        response: 'عذراً، حدث خطأ مؤقت. من فضلك حاول مرة أخرى.',
        intent: 'error',
        suggestedProduct: null
      };
    }
  }

  /**
   * مسح سجل المحادثة للمستخدم
   */
  clearHistory(userId) {
    this.conversationHistory.delete(userId);
  }

  /**
   * توليد رد ترحيبي
   */
  getWelcomeMessage() {
    return `مرحباً بك في Free Move Egypt!

أنا مساعدك الذكي للتعرف على منتجاتنا الطبية المبتكرة.

نحن نقدم لاصقات علاجية كندية معتمدة بتقنية فريدة لعلاج الآلام بشكل طبيعي وآمن.

دعني أساعدك في العثور على المنتج المناسب لك.

ما نوع الألم أو المشكلة التي تواجهها؟`;
  }

  /**
   * توليد رد للطلب
   */
  getOrderMessage(product) {
    return `ممتاز! سنساعدك في طلب ${product.name}.

للمتابعة، أحتاج منك المعلومات التالية:
1. الاسم الكامل
2. رقم الهاتف
3. العنوان الكامل (المحافظة - المدينة - الشارع)
4. طريقة التوصيل المفضلة (عادي 30ج / سريع 50ج / استلام مجاني)
5. طريقة الدفع (عند الاستلام / إلكتروني)

يمكنك إرسال المعلومات الآن.`;
  }
}

module.exports = new AIService();
