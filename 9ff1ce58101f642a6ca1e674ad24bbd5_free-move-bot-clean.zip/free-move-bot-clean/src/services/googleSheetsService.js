const { google } = require('googleapis');

/**
 * خدمة التصدير إلى Google Sheets
 */
class GoogleSheetsService {
  constructor() {
    this.auth = null;
    this.sheets = null;
    this.spreadsheetId = process.env.GOOGLE_SHEETS_SPREADSHEET_ID;
    this.initialize();
  }

  /**
   * تهيئة الاتصال بـ Google Sheets
   */
  async initialize() {
    try {
      if (!process.env.GOOGLE_SHEETS_CLIENT_EMAIL || !process.env.GOOGLE_SHEETS_PRIVATE_KEY) {
        console.warn('⚠ بيانات Google Sheets غير مكتملة');
        return;
      }

      this.auth = new google.auth.GoogleAuth({
        credentials: {
          client_email: process.env.GOOGLE_SHEETS_CLIENT_EMAIL,
          private_key: process.env.GOOGLE_SHEETS_PRIVATE_KEY.replace(/\\n/g, '\n')
        },
        scopes: ['https://www.googleapis.com/auth/spreadsheets']
      });

      this.sheets = google.sheets({ version: 'v4', auth: this.auth });
      console.log('✓ تم الاتصال بـ Google Sheets بنجاح');
    } catch (error) {
      console.error('خطأ في تهيئة Google Sheets:', error.message);
    }
  }

  /**
   * إضافة صف إلى ورقة
   */
  async appendRow(sheetName, values) {
    try {
      if (!this.sheets) {
        throw new Error('Google Sheets غير مهيأ');
      }

      const response = await this.sheets.spreadsheets.values.append({
        spreadsheetId: this.spreadsheetId,
        range: `${sheetName}!A:Z`,
        valueInputOption: 'USER_ENTERED',
        requestBody: {
          values: [values]
        }
      });

      return response.data;
    } catch (error) {
      console.error('خطأ في إضافة صف:', error.message);
      throw error;
    }
  }

  /**
   * تصدير طلب إلى Google Sheets
   */
  async exportOrder(order, customer, items) {
    try {
      const orderRow = [
        order.id,
        new Date(order.created_at).toLocaleString('ar-EG'),
        customer.name,
        customer.phone || '',
        customer.address || '',
        items.map(item => item.product_name).join(', '),
        items.reduce((sum, item) => sum + item.quantity, 0),
        order.total_price,
        order.delivery_type || '',
        order.payment_method || '',
        order.status,
        order.tracking_number || '',
        order.notes || ''
      ];

      await this.appendRow('الطلبات', orderRow);
      console.log(`✓ تم تصدير الطلب ${order.id} إلى Google Sheets`);
    } catch (error) {
      console.error('خطأ في تصدير الطلب:', error.message);
    }
  }

  /**
   * تصدير عميل إلى Google Sheets
   */
  async exportCustomer(customer) {
    try {
      const customerRow = [
        customer.id,
        new Date(customer.created_at).toLocaleString('ar-EG'),
        customer.name,
        customer.phone || '',
        customer.email || '',
        customer.address || '',
        customer.city || '',
        customer.pain_type || '',
        customer.interest_level || '',
        customer.conversion_status || '',
        customer.interaction_count || 0,
        customer.notes || ''
      ];

      await this.appendRow('العملاء', customerRow);
      console.log(`✓ تم تصدير العميل ${customer.id} إلى Google Sheets`);
    } catch (error) {
      console.error('خطأ في تصدير العميل:', error.message);
    }
  }

  /**
   * إنشاء تقرير يومي
   */
  async createDailyReport(stats) {
    try {
      const today = new Date().toLocaleDateString('ar-EG');
      const reportRow = [
        today,
        stats.totalOrders || 0,
        stats.totalRevenue || 0,
        stats.newCustomers || 0,
        stats.conversionRate || 0,
        stats.averageOrderValue || 0,
        stats.topProduct || '',
        stats.pendingOrders || 0
      ];

      await this.appendRow('التقارير_اليومية', reportRow);
      console.log(`✓ تم إنشاء تقرير يومي في Google Sheets`);
    } catch (error) {
      console.error('خطأ في إنشاء التقرير:', error.message);
    }
  }

  /**
   * تهيئة الأوراق الأساسية
   */
  async initializeSheets() {
    try {
      if (!this.sheets) {
        console.warn('⚠ Google Sheets غير مهيأ');
        return;
      }

      const sheetsToCreate = [
        {
          name: 'الطلبات',
          headers: ['رقم الطلب', 'التاريخ', 'اسم العميل', 'الهاتف', 'العنوان', 'المنتجات', 'الكمية', 'المبلغ الإجمالي', 'نوع التوصيل', 'طريقة الدفع', 'الحالة', 'رقم التتبع', 'ملاحظات']
        },
        {
          name: 'العملاء',
          headers: ['معرف العميل', 'تاريخ التسجيل', 'الاسم', 'الهاتف', 'البريد الإلكتروني', 'العنوان', 'المدينة', 'نوع الألم', 'مستوى الاهتمام', 'حالة التحويل', 'عدد التفاعلات', 'ملاحظات']
        },
        {
          name: 'التقارير_اليومية',
          headers: ['التاريخ', 'إجمالي الطلبات', 'إجمالي المبيعات', 'عملاء جدد', 'معدل التحويل', 'متوسط قيمة الطلب', 'المنتج الأكثر مبيعاً', 'الطلبات المعلقة']
        }
      ];

      for (const sheet of sheetsToCreate) {
        try {
          await this.appendRow(sheet.name, sheet.headers);
          console.log(`✓ تم إنشاء ورقة ${sheet.name}`);
        } catch (error) {
          // الورقة موجودة مسبقاً
        }
      }
    } catch (error) {
      console.error('خطأ في تهيئة الأوراق:', error.message);
    }
  }
}

module.exports = new GoogleSheetsService();
