const axios = require('axios');
const crypto = require('crypto');

/**
 * خدمة التكامل مع Facebook Messenger API
 */
class FacebookService {
  constructor() {
    this.pageAccessToken = process.env.FACEBOOK_PAGE_ACCESS_TOKEN;
    this.verifyToken = process.env.FACEBOOK_VERIFY_TOKEN;
    this.appSecret = process.env.FACEBOOK_APP_SECRET;
    this.apiVersion = 'v18.0';
    this.baseUrl = `https://graph.facebook.com/${this.apiVersion}`;
  }

  /**
   * التحقق من webhook
   */
  verifyWebhook(mode, token, challenge) {
    if (mode === 'subscribe' && token === this.verifyToken) {
      console.log('✓ تم التحقق من webhook بنجاح');
      return challenge;
    }
    return null;
  }

  /**
   * التحقق من توقيع الطلب
   */
  verifyRequestSignature(signature, body) {
    if (!signature) {
      throw new Error('توقيع الطلب مفقود');
    }

    const elements = signature.split('=');
    const signatureHash = elements[1];

    const expectedHash = crypto
      .createHmac('sha256', this.appSecret)
      .update(body, 'utf8')
      .digest('hex');

    if (signatureHash !== expectedHash) {
      throw new Error('توقيع الطلب غير صالح');
    }

    return true;
  }

  /**
   * إرسال رسالة نصية
   */
  async sendTextMessage(recipientId, text) {
    try {
      const response = await axios.post(
        `${this.baseUrl}/me/messages`,
        {
          recipient: { id: recipientId },
          message: { text }
        },
        {
          params: { access_token: this.pageAccessToken }
        }
      );

      return response.data;
    } catch (error) {
      console.error('خطأ في إرسال الرسالة:', error.response?.data || error.message);
      throw error;
    }
  }

  /**
   * إرسال مؤشر الكتابة
   */
  async sendTypingIndicator(recipientId, isTyping = true) {
    try {
      await axios.post(
        `${this.baseUrl}/me/messages`,
        {
          recipient: { id: recipientId },
          sender_action: isTyping ? 'typing_on' : 'typing_off'
        },
        {
          params: { access_token: this.pageAccessToken }
        }
      );
    } catch (error) {
      console.error('خطأ في إرسال مؤشر الكتابة:', error.message);
    }
  }

  /**
   * إرسال رسالة بأزرار
   */
  async sendButtonMessage(recipientId, text, buttons) {
    try {
      const response = await axios.post(
        `${this.baseUrl}/me/messages`,
        {
          recipient: { id: recipientId },
          message: {
            attachment: {
              type: 'template',
              payload: {
                template_type: 'button',
                text,
                buttons
              }
            }
          }
        },
        {
          params: { access_token: this.pageAccessToken }
        }
      );

      return response.data;
    } catch (error) {
      console.error('خطأ في إرسال رسالة الأزرار:', error.response?.data || error.message);
      throw error;
    }
  }

  /**
   * إرسال قالب عام (بطاقات)
   */
  async sendGenericTemplate(recipientId, elements) {
    try {
      const response = await axios.post(
        `${this.baseUrl}/me/messages`,
        {
          recipient: { id: recipientId },
          message: {
            attachment: {
              type: 'template',
              payload: {
                template_type: 'generic',
                elements
              }
            }
          }
        },
        {
          params: { access_token: this.pageAccessToken }
        }
      );

      return response.data;
    } catch (error) {
      console.error('خطأ في إرسال القالب:', error.response?.data || error.message);
      throw error;
    }
  }

  /**
   * جلب معلومات المستخدم
   */
  async getUserProfile(userId) {
    try {
      const response = await axios.get(
        `${this.baseUrl}/${userId}`,
        {
          params: {
            fields: 'first_name,last_name,profile_pic',
            access_token: this.pageAccessToken
          }
        }
      );

      return response.data;
    } catch (error) {
      console.error('خطأ في جلب معلومات المستخدم:', error.response?.data || error.message);
      return null;
    }
  }

  /**
   * الرد على تعليق
   */
  async replyToComment(commentId, message) {
    try {
      const response = await axios.post(
        `${this.baseUrl}/${commentId}/comments`,
        {
          message
        },
        {
          params: { access_token: this.pageAccessToken }
        }
      );

      return response.data;
    } catch (error) {
      console.error('خطأ في الرد على التعليق:', error.response?.data || error.message);
      throw error;
    }
  }

  /**
   * إرسال رسالة خاصة من تعليق
   */
  async sendPrivateReply(commentId, message) {
    try {
      const response = await axios.post(
        `${this.baseUrl}/${commentId}/private_replies`,
        {
          message
        },
        {
          params: { access_token: this.pageAccessToken }
        }
      );

      return response.data;
    } catch (error) {
      console.error('خطأ في إرسال رسالة خاصة:', error.response?.data || error.message);
      throw error;
    }
  }

  /**
   * جلب التعليقات على منشور
   */
  async getPostComments(postId) {
    try {
      const response = await axios.get(
        `${this.baseUrl}/${postId}/comments`,
        {
          params: {
            fields: 'id,from,message,created_time',
            access_token: this.pageAccessToken
          }
        }
      );

      return response.data.data || [];
    } catch (error) {
      console.error('خطأ في جلب التعليقات:', error.response?.data || error.message);
      return [];
    }
  }

  /**
   * إنشاء بطاقة منتج
   */
  createProductCard(product) {
    return {
      title: product.name,
      subtitle: `${product.salePrice} جنيه (خصم ${product.discount}٪)\n${product.description}`,
      image_url: product.image_url || 'https://via.placeholder.com/300x200?text=Free+Move',
      buttons: [
        {
          type: 'postback',
          title: 'اطلب الآن',
          payload: `ORDER_PRODUCT_${product.id}`
        },
        {
          type: 'postback',
          title: 'معلومات أكثر',
          payload: `INFO_PRODUCT_${product.id}`
        }
      ]
    };
  }
}

module.exports = new FacebookService();
