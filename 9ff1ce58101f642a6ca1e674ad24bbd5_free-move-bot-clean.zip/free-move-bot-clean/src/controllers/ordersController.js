const { db } = require('../config/database');
const { v4: uuidv4 } = require('uuid');
const googleSheetsService = require('../services/googleSheetsService');

/**
 * معالج الطلبات
 */
class OrdersController {
  /**
   * جلب جميع الطلبات
   */
  getAllOrders(req, res) {
    try {
      const { status, limit = 100, offset = 0 } = req.query;

      let query = `
        SELECT o.*, c.name as customer_name, c.phone as customer_phone
        FROM orders o
        JOIN customers c ON o.customer_id = c.id
      `;

      const params = [];
      if (status) {
        query += ' WHERE o.status = ?';
        params.push(status);
      }

      query += ' ORDER BY o.created_at DESC LIMIT ? OFFSET ?';
      params.push(parseInt(limit), parseInt(offset));

      const orders = db.prepare(query).all(...params);

      res.json({
        success: true,
        count: orders.length,
        data: orders
      });
    } catch (error) {
      console.error('خطأ في جلب الطلبات:', error);
      res.status(500).json({ success: false, error: error.message });
    }
  }

  /**
   * جلب طلب واحد
   */
  getOrder(req, res) {
    try {
      const { id } = req.params;

      const order = db.prepare(`
        SELECT o.*, c.name as customer_name, c.phone as customer_phone, c.address as customer_address
        FROM orders o
        JOIN customers c ON o.customer_id = c.id
        WHERE o.id = ?
      `).get(id);

      if (!order) {
        return res.status(404).json({ success: false, error: 'الطلب غير موجود' });
      }

      // جلب المنتجات
      const items = db.prepare(`
        SELECT oi.*, p.name as product_name
        FROM order_items oi
        JOIN products p ON oi.product_id = p.id
        WHERE oi.order_id = ?
      `).all(id);

      res.json({
        success: true,
        data: {
          ...order,
          items
        }
      });
    } catch (error) {
      console.error('خطأ في جلب الطلب:', error);
      res.status(500).json({ success: false, error: error.message });
    }
  }

  /**
   * إنشاء طلب جديد
   */
  createOrder(req, res) {
    try {
      const { customer_id, items, delivery_type, payment_method, notes } = req.body;

      if (!customer_id || !items || items.length === 0) {
        return res.status(400).json({ success: false, error: 'بيانات غير كاملة' });
      }

      // حساب الإجمالي
      let totalPrice = 0;
      for (const item of items) {
        totalPrice += item.price * item.quantity;
      }

      // حساب تكلفة التوصيل
      const deliveryCost = this.calculateDeliveryCost(delivery_type);
      const finalTotal = totalPrice + deliveryCost;

      // إنشاء الطلب
      const orderId = uuidv4();
      const trackingNumber = this.generateTrackingNumber();

      db.prepare(`
        INSERT INTO orders (id, customer_id, status, total_price, delivery_type, delivery_cost, payment_method, tracking_number, notes)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(
        orderId,
        customer_id,
        'قيد الانتظار',
        finalTotal,
        delivery_type,
        deliveryCost,
        payment_method,
        trackingNumber,
        notes || null
      );

      // إضافة المنتجات
      const insertItem = db.prepare(`
        INSERT INTO order_items (id, order_id, product_id, quantity, price, subtotal)
        VALUES (?, ?, ?, ?, ?, ?)
      `);

      for (const item of items) {
        insertItem.run(
          uuidv4(),
          orderId,
          item.product_id,
          item.quantity,
          item.price,
          item.price * item.quantity
        );
      }

      // حفظ تاريخ الحالة
      db.prepare(`
        INSERT INTO order_status_history (id, order_id, status)
        VALUES (?, ?, ?)
      `).run(uuidv4(), orderId, 'قيد الانتظار');

      // تصدير إلى Google Sheets
      const customer = db.prepare('SELECT * FROM customers WHERE id = ?').get(customer_id);
      googleSheetsService.exportOrder(
        { id: orderId, created_at: new Date(), total_price: finalTotal, delivery_type, payment_method, status: 'قيد الانتظار', tracking_number: trackingNumber, notes },
        customer,
        items
      ).catch(err => console.error('خطأ في التصدير:', err));

      res.status(201).json({
        success: true,
        data: {
          id: orderId,
          tracking_number: trackingNumber,
          total_price: finalTotal
        }
      });
    } catch (error) {
      console.error('خطأ في إنشاء الطلب:', error);
      res.status(500).json({ success: false, error: error.message });
    }
  }

  /**
   * تحديث حالة الطلب
   */
  updateOrderStatus(req, res) {
    try {
      const { id } = req.params;
      const { status, notes } = req.body;

      if (!status) {
        return res.status(400).json({ success: false, error: 'الحالة مطلوبة' });
      }

      // تحديث الطلب
      const result = db.prepare(`
        UPDATE orders
        SET status = ?, notes = ?, updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `).run(status, notes || null, id);

      if (result.changes === 0) {
        return res.status(404).json({ success: false, error: 'الطلب غير موجود' });
      }

      // حفظ تاريخ الحالة
      db.prepare(`
        INSERT INTO order_status_history (id, order_id, status, notes)
        VALUES (?, ?, ?, ?)
      `).run(uuidv4(), id, status, notes || null);

      res.json({
        success: true,
        message: 'تم تحديث حالة الطلب بنجاح'
      });
    } catch (error) {
      console.error('خطأ في تحديث الطلب:', error);
      res.status(500).json({ success: false, error: error.message });
    }
  }

  /**
   * حساب تكلفة التوصيل
   */
  calculateDeliveryCost(deliveryType) {
    const costs = {
      'standard': 30,
      'fast': 50,
      'pickup': 0
    };
    return costs[deliveryType] || 30;
  }

  /**
   * توليد رقم تتبع
   */
  generateTrackingNumber() {
    const prefix = 'FM';
    const timestamp = Date.now().toString().slice(-8);
    const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
    return `${prefix}${timestamp}${random}`;
  }

  /**
   * إحصائيات الطلبات
   */
  getOrderStats(req, res) {
    try {
      const { period = 'today' } = req.query;

      let dateFilter = '';
      if (period === 'today') {
        dateFilter = "DATE(created_at) = DATE('now')";
      } else if (period === 'week') {
        dateFilter = "created_at >= DATE('now', '-7 days')";
      } else if (period === 'month') {
        dateFilter = "created_at >= DATE('now', '-30 days')";
      }

      const stats = db.prepare(`
        SELECT
          COUNT(*) as total_orders,
          SUM(total_price) as total_revenue,
          AVG(total_price) as average_order_value,
          COUNT(DISTINCT customer_id) as unique_customers
        FROM orders
        ${dateFilter ? 'WHERE ' + dateFilter : ''}
      `).get();

      const statusCounts = db.prepare(`
        SELECT status, COUNT(*) as count
        FROM orders
        ${dateFilter ? 'WHERE ' + dateFilter : ''}
        GROUP BY status
      `).all();

      res.json({
        success: true,
        data: {
          ...stats,
          by_status: statusCounts
        }
      });
    } catch (error) {
      console.error('خطأ في جلب الإحصائيات:', error);
      res.status(500).json({ success: false, error: error.message });
    }
  }
}

module.exports = new OrdersController();
