const { db } = require('../config/database');
const facebookService = require('../services/facebookService');
const aiService = require('../services/aiServiceFree');
const { v4: uuidv4 } = require('uuid');

/**
 * معالج أحداث Facebook Messenger
 */
class MessengerController {
  /**
   * التحقق من webhook
   */
  verifyWebhook(req, res) {
    const mode = req.query['hub.mode'];
    const token = req.query['hub.verify_token'];
    const challenge = req.query['hub.challenge'];

    const result = facebookService.verifyWebhook(mode, token, challenge);
    
    if (result) {
      res.status(200).send(result);
    } else {
      res.status(403).send('فشل التحقق');
    }
  }

  /**
   * معالجة الأحداث الواردة
   */
  async handleWebhook(req, res) {
    try {
      // التحقق من التوقيع
      const signature = req.headers['x-hub-signature-256'];
      facebookService.verifyRequestSignature(signature, JSON.stringify(req.body));

      // إرسال 200 OK فوراً
      res.status(200).send('EVENT_RECEIVED');

      const body = req.body;

      // معالجة كل إدخال
      if (body.object === 'page') {
        for (const entry of body.entry) {
          // معالجة الرسائل
          if (entry.messaging) {
            for (const event of entry.messaging) {
              await this.handleMessagingEvent(event);
            }
          }

          // معالجة التعليقات
          if (entry.changes) {
            for (const change of entry.changes) {
              if (change.field === 'feed' && change.value.item === 'comment') {
                await this.handleCommentEvent(change.value);
              }
            }
          }
        }
      }
    } catch (error) {
      console.error('خطأ في معالجة webhook:', error);
      res.status(500).send('خطأ في المعالجة');
    }
  }

  /**
   * معالجة حدث رسالة
   */
  async handleMessagingEvent(event) {
    const senderId = event.sender.id;
    const recipientId = event.recipient.id;

    // تجاهل رسائل صفحة
    if (senderId === recipientId) return;

    if (event.message) {
      await this.handleMessage(senderId, event.message);
    } else if (event.postback) {
      await this.handlePostback(senderId, event.postback);
    }
  }

  /**
   * معالجة رسالة نصية
   */
  async handleMessage(senderId, message) {
    try {
      // إظهار مؤشر الكتابة
      await facebookService.sendTypingIndicator(senderId, true);

      // جلب أو إنشاء بيانات العميل
      const customer = await this.getOrCreateCustomer(senderId);

      // توليد رد ذكي
      const { response, intent, suggestedProduct } = await aiService.generateResponse(
        senderId,
        message.text,
        customer
      );

      // حفظ المحادثة
      await this.saveConversation(customer.id, message.text, response, intent);

      // تحديث عداد التفاعلات
      await this.updateCustomerInteractions(customer.id);

      // إرسال الرد
      await facebookService.sendTextMessage(senderId, response);

      // إرسال بطاقة المنتج إن وجد
      if (suggestedProduct && intent === 'pain') {
        await facebookService.sendGenericTemplate(senderId, [
          facebookService.createProductCard(suggestedProduct)
        ]);
      }

      // إيقاف مؤشر الكتابة
      await facebookService.sendTypingIndicator(senderId, false);
    } catch (error) {
      console.error('خطأ في معالجة الرسالة:', error);
      await facebookService.sendTextMessage(
        senderId,
        'عذراً، حدث خطأ مؤقت. من فضلك حاول مرة أخرى.'
      );
    }
  }

  /**
   * معالجة postback (نقر على زر)
   */
  async handlePostback(senderId, postback) {
    try {
      const payload = postback.payload;
      const customer = await this.getOrCreateCustomer(senderId);

      if (payload.startsWith('ORDER_PRODUCT_')) {
        const productId = payload.replace('ORDER_PRODUCT_', '');
        const message = aiService.getOrderMessage({ id: productId, name: 'المنتج' });
        await facebookService.sendTextMessage(senderId, message);
      } else if (payload.startsWith('INFO_PRODUCT_')) {
        const productId = payload.replace('INFO_PRODUCT_', '');
        // إرسال معلومات المنتج
        await facebookService.sendTextMessage(senderId, 'معلومات تفصيلية عن المنتج...');
      } else if (payload === 'GET_STARTED') {
        await facebookService.sendTextMessage(senderId, aiService.getWelcomeMessage());
      }
    } catch (error) {
      console.error('خطأ في معالجة postback:', error);
    }
  }

  /**
   * معالجة تعليق
   */
  async handleCommentEvent(commentData) {
    try {
      const commentId = commentData.comment_id;
      const commentText = commentData.message;

      // الرد على التعليق
      await facebookService.replyToComment(
        commentId,
        'شكراً لتعليقك! سنتواصل معك عبر رسالة خاصة.'
      );

      // إرسال رسالة خاصة
      await facebookService.sendPrivateReply(
        commentId,
        'مرحباً! شكراً لاهتمامك بمنتجات Free Move. كيف يمكننا مساعدتك؟'
      );
    } catch (error) {
      console.error('خطأ في معالجة التعليق:', error);
    }
  }

  /**
   * جلب أو إنشاء عميل
   */
  async getOrCreateCustomer(facebookId) {
    try {
      // البحث عن العميل
      const existingCustomer = db.prepare(
        'SELECT * FROM customers WHERE facebook_id = ?'
      ).get(facebookId);

      if (existingCustomer) {
        return existingCustomer;
      }

      // جلب معلومات من Facebook
      const profile = await facebookService.getUserProfile(facebookId);
      const name = profile ? `${profile.first_name} ${profile.last_name}` : 'عميل جديد';

      // إنشاء عميل جديد
      const customerId = uuidv4();
      db.prepare(`
        INSERT INTO customers (id, facebook_id, name)
        VALUES (?, ?, ?)
      `).run(customerId, facebookId, name);

      return {
        id: customerId,
        facebook_id: facebookId,
        name
      };
    } catch (error) {
      console.error('خطأ في جلب/إنشاء العميل:', error);
      throw error;
    }
  }

  /**
   * حفظ المحادثة
   */
  async saveConversation(customerId, message, response, intent) {
    try {
      db.prepare(`
        INSERT INTO conversations (id, customer_id, message_type, message_content, bot_response, intent)
        VALUES (?, ?, ?, ?, ?, ?)
      `).run(uuidv4(), customerId, 'text', message, response, intent);
    } catch (error) {
      console.error('خطأ في حفظ المحادثة:', error);
    }
  }

  /**
   * تحديث عداد التفاعلات
   */
  async updateCustomerInteractions(customerId) {
    try {
      db.prepare(`
        UPDATE customers
        SET interaction_count = interaction_count + 1,
            updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `).run(customerId);
    } catch (error) {
      console.error('خطأ في تحديث التفاعلات:', error);
    }
  }
}

module.exports = new MessengerController();
