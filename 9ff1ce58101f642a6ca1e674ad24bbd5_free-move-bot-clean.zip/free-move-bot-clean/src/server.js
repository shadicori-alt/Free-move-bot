require('dotenv').config();
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');
const { initDatabase } = require('./config/database');

// تهيئة التطبيق
const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// تهيئة قاعدة البيانات
initDatabase();

// Static files
app.use(express.static(path.join(__dirname, '../')));

// المسارات
app.use('/api/messenger', require('./routes/messenger'));
app.use('/api/orders', require('./routes/orders'));
app.use('/api/customers', require('./routes/customers'));
app.use('/api/products', require('./routes/products'));

// الصفحة الرئيسية - صفحة HTML جميلة
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../status.html'));
});

// فحص الصحة
app.get('/health', (req, res) => {
  res.json({
    status: 'healthy',
    timestamp: new Date().toISOString()
  });
});

// معالج الأخطاء
app.use((err, req, res, next) => {
  console.error('خطأ في الخادم:', err);
  res.status(500).json({
    success: false,
    error: 'حدث خطأ داخلي في الخادم'
  });
});

// معالج المسارات غير الموجودة
app.use((req, res) => {
  res.status(404).json({
    success: false,
    error: 'المسار غير موجود'
  });
});

// بدء الخادم
app.listen(PORT, () => {
  console.log('='.repeat(60));
  console.log(`✓ بوت Free Move يعمل على المنفذ ${PORT}`);
  console.log(`✓ البيئة: ${process.env.NODE_ENV || 'development'}`);
  console.log(`✓ الوقت: ${new Date().toLocaleString('ar-EG')}`);
  console.log('='.repeat(60));
});

module.exports = app;
