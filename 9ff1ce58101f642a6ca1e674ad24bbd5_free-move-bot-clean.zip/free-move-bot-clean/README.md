# بوت Free Move Egypt للـ Facebook Messenger

## نظرة عامة
بوت ذكي لـ Facebook Messenger مخصص لمنتجات Free Move الطبية - لاصقات علاج الألم الكندية.

## المميزات
✅ مجاني 100% - لا يحتاج OpenAI API  
✅ الذكاء الاصطناعي بالعربية  
✅ يعمل مع جميع منتجات Free Move  
✅ سريع الاستجابة (خلال ثوانٍ)  
✅ يعمل 24/7  

## التثبيت والإعداد

### 1. متطلبات
- Node.js 18+
- حساب Facebook Developer
- صفحة Facebook للـ Business

### 2. إعداد البيئة
```bash
# تثبيت المكتبات
npm install

# إعداد متغيرات البيئة
cp .env.example .env
# املأ المتغيرات في .env
```

### 3. تشغيل البوت
```bash
npm start
```

### 4. إعداد Webhook في Facebook
1. اذهب لـ Facebook Developers
2. أضف Webhook URL: `https://your-codespace-url/api/messenger/webhook`
3. استخدم Verify Token: `FreeMoveBot2025`

## البنية التقنية
```
src/
├── controllers/
│   └── messengerController.js   # معالجة الأحداث
├── services/
│   ├── aiServiceFree.js         # الذكاء الاصطناعي المجاني
│   └── facebookService.js       # خدمة Facebook
├── routes/
│   └── messenger.js             # مسارات Webhook
└── config/
    └── products.js              # إعدادات المنتجات
```

## المنتجات المدعومة
- **لاصق الرقبة** - للصداع وآلام الرقبة
- **لاصق الظهر** - لآلام الظهر والعمود الفقري  
- **لاصق الركبة** - لآلام الركبة والمفاصل
- **لاصق الكتف** - لآلام الكتف والذراع

## الدعم
للاستفسارات، راسل الصفحة: [Free Move Egypt](https://facebook.com/freemoveegypt)

## الترخيص
مملوك لـ Free Move Egypt - جميع الحقوق محفوظة