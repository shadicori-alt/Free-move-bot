#!/bin/bash

echo "🚀 بدء إعداد بوت Free Move Egypt..."
echo "========================================"

# تثبيت المكتبات
echo "📦 تثبيت المكتبات..."
npm install

echo ""

# إنشاء ملف .env من النموذج
echo "⚙️ إعداد متغيرات البيئة..."
if [ ! -f ".env" ]; then
    cp .env.example .env
    echo "✅ تم إنشاء ملف .env"
    echo "📝 يرجى ملء المتغيرات في .env"
else
    echo "⚠️ ملف .env موجود بالفعل"
fi

echo ""

# فحص المنفذ
echo "🔍 فحص المنفذ 3000..."
if lsof -Pi :3000 -sTCP:LISTEN -t >/dev/null ; then
    echo "⚠️ المنفذ 3000 مُستخدم"
    echo "🛠️ سيتم تشغيل البوت على منفذ آخر"
else
    echo "✅ المنفذ 3000 متاح"
fi

echo ""

# تشغيل البوت
echo "🚀 بدء تشغيل البوت..."
export PORT=3000
export NODE_ENV=production

echo "========================================"
echo "🎯 البوت جاهز للعمل!"
echo "📱 webhook URL: https://your-codespace-url/api/messenger/webhook"
echo "🔐 Verify Token: FreeMoveBot2025"
echo "========================================"

npm start